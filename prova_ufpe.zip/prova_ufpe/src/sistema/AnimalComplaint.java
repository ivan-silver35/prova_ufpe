package sistema;

public class AnimalComplaint extends Complaint {
		
}
