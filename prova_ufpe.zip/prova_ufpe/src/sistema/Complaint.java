package sistema;

public class Complaint {
	String reclamacao;
	String observacoes;
	String nome_reclamante;
	String endereco;
	String provincia;
	String cidade;
	String estado;
	String cod_postal;
	String num_cel;
	String email;
	String raca_ani;
	int quantidade;
	String dat_even;
	String enderec; 
	String complement;
	String num_cel_anim;
	int qtd_refe = 0;
	int qtd_pess = 0;
	int qtd_pess_hos = 0;
	int qtd_mort = 0;
	String  loc_atend_med;
	String ref_suspei;
	
	
	public String getReclamacao() {
		return reclamacao;
	}
	public void setReclamacao(String reclamacao) {
		this.reclamacao = reclamacao;
	}
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	public String getNome_reclamante() {
		return nome_reclamante;
	}
	public void setNome_reclamante(String nome_reclamante) {
		this.nome_reclamante = nome_reclamante;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getCod_postal() {
		return cod_postal;
	}
	public void setCod_postal(String cod_postal) {
		this.cod_postal = cod_postal;
	}
	public String getNum_cel() {
		return num_cel;
	}
	public void setNum_cel(String num_cel) {
		this.num_cel = num_cel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRaca_ani() {
		return raca_ani;
	}
	public void setRaca_ani(String raca_ani) {
		this.raca_ani = raca_ani;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public String getDat_even() {
		return dat_even;
	}
	public void setDat_even(String dat_even) {
		this.dat_even = dat_even;
	}
	public String getEnderec() {
		return enderec;
	}
	public void setEnderec(String enderec) {
		this.enderec = enderec;
	}
	public String getComplement() {
		return complement;
	}
	public void setComplement(String complement) {
		this.complement = complement;
	}
	public String getNum_cel_anim() {
		return num_cel_anim;
	}
	public void setNum_cel_anim(String num_cel_anim) {
		this.num_cel_anim = num_cel_anim;
	}
	public int getQtd_refe() {
		return qtd_refe;
	}
	public void setQtd_refe(int qtd_refe) {
		this.qtd_refe = qtd_refe;
	}
	public int getQtd_pess() {
		return qtd_pess;
	}
	public void setQtd_pess(int qtd_pess) {
		this.qtd_pess = qtd_pess;
	}
	public int getQtd_pess_hos() {
		return qtd_pess_hos;
	}
	public void setQtd_pess_hos(int qtd_pess_hos) {
		this.qtd_pess_hos = qtd_pess_hos;
	}
	public int getQtd_mort() {
		return qtd_mort;
	}
	public void setQtd_mort(int qtd_mort) {
		this.qtd_mort = qtd_mort;
	}
	public String getLoc_atend_med() {
		return loc_atend_med;
	}
	public void setLoc_atend_med(String loc_atend_med) {
		this.loc_atend_med = loc_atend_med;
	}
	public String getRef_suspei() {
		return ref_suspei;
	}
	public void setRef_suspei(String ref_suspei) {
		this.ref_suspei = ref_suspei;
	}
}
