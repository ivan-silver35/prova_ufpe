package sistema;

public class FoodComplaint extends Complaint {

}
