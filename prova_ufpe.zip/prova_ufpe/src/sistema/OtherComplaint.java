package sistema;

public class OtherComplaint extends Complaint  {
	String local_vazam_esgo;
	
}
