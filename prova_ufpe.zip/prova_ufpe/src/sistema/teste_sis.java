package sistema;

public class teste_sis {

	public static void main(String[] args) {
		
		OtherComplaint ot = new OtherComplaint();
		ot.setCidade("recife");
		System.out.println(ot.getCidade());
		
		
		FoodComplaint fo = new FoodComplaint();
		
		fo.setCidade("natal");
		System.out.println(fo.getCidade());
		
		
		AnimalComplaint ani = new AnimalComplaint();
		ani.setCidade("paraiba");
		System.out.println(ani.getCidade());

	}

}
